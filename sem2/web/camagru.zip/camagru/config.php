<?php 
	$DB_DSN = "mysql:host=localhost;dbname=dbMkMeMgc";
	$DB_USER = "root";
	$DB_PASSWORD = "cullygme";
?>